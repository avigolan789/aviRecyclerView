package com.example.avirecycleview1;



public class MyData {

    static String[] nameArray = {"Pikachu", "Bulbasaur", "Charmander", "Snorlax", "Squirtle", "rattata"};
    //static String[] versionArray = {"1.5", "1.6", "2.0-2.1", "2.2-2.2.3", "2.3-2.3.7", "3.0-3.2.6", "4.0-4.0.4", "4.1-4.3.1", "4.4-4.4.4", "5.0-5.1.1","6.0-6.0.1"};

    static Integer[] drawableArray = {R.drawable.pickachosmall, R.drawable.balbazr, R.drawable.chamnder,
            R.drawable.snorlax, R.drawable.squirtle, R.drawable.ratta};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5};
}
