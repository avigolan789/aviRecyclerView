package com.example.avirecycleview1;

import android.view.View;

public interface RecyclerViewInterface {
    void onItemClick(int pos, View view);

}
